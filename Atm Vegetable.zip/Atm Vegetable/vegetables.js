const Carrot = {
  price: 12,
  maxQ: 5.0,
}
const Pea = {
  price: 24,
  maxQ: 5.0,
}
const Potato = {
  price: 20,
  maxQ: 5.0,
}
const Cauliflower = {
  price: 15,
  maxQ: 5.0,
}
const Brinjal = {
  price: 30,
  maxQ: 5.0,
}
const Cabbage = {
  price: 25,
  maxQ: 5.0,
}
const Bitter_gourd = {
  price: 15,
  maxQ: 5.0,
}
const Mushroom = {
  price: 100,
  maxQ: 5.0,
}
// console.log(Carrot.price);

var ans;
function Add(i) {
  var veg = document.getElementsByTagName("button");
  ans = veg[i].parentElement.children[2].innerText;
  console.log(ans);
}

var Total_p = 0;
function weight(w) {
  if (w >= 25) {
    w = w / 1000.0;
  }
  switch (ans) {
    case 'Carrot':
      if (Carrot.maxQ >= w) {
        Total_p += Carrot.price * w;
        Carrot.maxQ -= w;
        console.log(Carrot.maxQ);
      }
      else {
        alert("cannot buy");
      }
      break;

    case 'Pea':
      if (Pea.maxQ >= w) {
        Total_p += Pea.price * w;
        Pea.maxQ -= w;
        console.log(Pea.maxQ);
      }
      else {
        alert("cannot buy");
      }
      break;
    case 'Potato':
      if (Potato.maxQ >= w) {
        Total_p += Potato.price * w;
        Potato.maxQ -= w;
        console.log(Potato.maxQ);
      }
      else {
        alert("cannot buy");
      }
      break;
    case 'Mushroom':
      if (Mushroom.maxQ >= w) {
        Total_p += Mushroom.price * w;
        Mushroom.maxQ -= w;
        console.log(Mushroom.maxQ);
      }
      else {
        alert("cannot buy");
      }
      break;
    case 'Bitter gourd':
      if (Bitter_gourd.maxQ >= w) {
        Total_p += Bitter_gourd.price * w;
        Bitter_gourd.maxQ -= w;
        
      }
      else {
        alert("cannot buy");
      }
      break;
    case 'Cabbage':
      if (Cabbage.maxQ >= w) {
        Total_p += Cabbage.price * w;
        Cabbage.maxQ -= w;
       
      }
      else {
        alert("cannot buy");
      }
      break;
    case 'Brinjal':
      if (Brinjal.maxQ >= w) {
        Total_p += Brinjal.price * w;
        Brinjal.maxQ -= w;
        
      }
      else {
        alert("cannot buy");
      }
      break;

    case 'Cauliflower':
      if (Cauliflower.maxQ >= w) {
        Total_p += Cauliflower.price * w;
        Cauliflower.maxQ -= w;
        
      }
      else {
        alert("cannot buy");
      }
      break;
  }


}
function Pay() {
  document.getElementById("price").innerHTML = Total_p;
}